#define UTS_RELEASE "4.4.52-armada-17.10.3-g44275f8"
