/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "arm64"
#define UTS_VERSION "#1 SMP PREEMPT Mon Jan 6 18:06:21 CST 2020"
#define LINUX_COMPILE_BY "zl"
#define LINUX_COMPILE_HOST "glinet"
#define LINUX_COMPILER "gcc version 5.2.1 20151005 (Linaro GCC 5.2-2015.11-2) "
