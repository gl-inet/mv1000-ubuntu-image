#include <asm-generic/ftrace.h>
