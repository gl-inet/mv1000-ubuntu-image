#define UTS_RELEASE "4.4.52-armada-17.10.3-ge1b9bf1"
